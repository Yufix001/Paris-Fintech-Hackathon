import { Check, AlertTriangle, Sparkles } from "lucide-react";

export function StrengthsAndImprovements() {
  const strengths = [
    { title: "Équipe technique solide", sub: "2 docteurs ML, ex-Stripe et BNP Paribas" },
    { title: "Traction démontrée · +18% MoM", sub: "34 clients B2B européens" },
    { title: "Innovation IA brevetable", sub: "Algo détection fraude propriétaire" },
    { title: "Marché EU prioritaire", sub: "PSD2/PSD3 & souveraineté financière" },
  ];

  const improvements = [
    { title: "Plan d'impact ESG", sub: "+8 points sur Horizon Europe" },
    { title: "Roadmap 36 mois détaillée", sub: "Requis par EIC Accelerator" },
    { title: "Diversité fondateurs", sub: "+12 points sur Women TechEU" },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      {/* Points forts */}
      <div className="bg-[#0E0F11] border border-[#24262B] rounded-[10px] p-5">
        <div className="flex items-center gap-2 mb-4">
          <div className="w-[18px] h-[18px] rounded-md bg-emerald-500/15 text-emerald-400 flex items-center justify-center">
            <Check className="w-3 h-3" strokeWidth={3} />
          </div>
          <h3 className="text-sm font-semibold text-[#F0F2F5]">
            Points forts du dossier
          </h3>
        </div>

        <ul className="divide-y divide-[#1A1C20]">
          {strengths.map((item, i) => (
            <li key={i} className="grid grid-cols-[20px_1fr] gap-3 py-2.5 items-start">
              <div className="w-[18px] h-[18px] rounded-full bg-emerald-500 text-[#08090A] flex items-center justify-center mt-0.5 flex-shrink-0">
                <Check className="w-2.5 h-2.5" strokeWidth={3.5} />
              </div>
              <div>
                <div className="text-[13px] font-medium text-[#F0F2F5]">{item.title}</div>
                <div className="text-xs text-[#9DA3AC] mt-0.5">{item.sub}</div>
              </div>
            </li>
          ))}
        </ul>
      </div>

      {/* À renforcer */}
      <div className="bg-[#0E0F11] border border-[#24262B] rounded-[10px] p-5">
        <div className="flex items-center gap-2 mb-4">
          <div className="w-[18px] h-[18px] rounded-md bg-amber-500/15 text-amber-400 flex items-center justify-center">
            <AlertTriangle className="w-3 h-3" strokeWidth={2.5} />
          </div>
          <h3 className="text-sm font-semibold text-[#F0F2F5]">À renforcer</h3>
        </div>

        <ul className="divide-y divide-[#1A1C20]">
          {improvements.map((item, i) => (
            <li key={i} className="grid grid-cols-[20px_1fr] gap-3 py-2.5 items-start">
              <div className="w-[18px] h-[18px] rounded-full bg-amber-400 text-[#08090A] flex items-center justify-center mt-0.5 flex-shrink-0 text-[10px] font-bold">
                !
              </div>
              <div>
                <div className="text-[13px] font-medium text-[#F0F2F5]">{item.title}</div>
                <div className="text-xs text-[#9DA3AC] mt-0.5">{item.sub}</div>
              </div>
            </li>
          ))}
        </ul>

        {/* Insight IA box */}
        <div className="mt-4 bg-purple-500/[0.14] border border-purple-500/35 rounded-lg p-3.5">
          <div className="flex items-center gap-1.5 mb-1.5">
            <Sparkles className="w-2.5 h-2.5 text-purple-300" strokeWidth={3} />
            <span className="text-[11px] font-semibold text-purple-300 uppercase tracking-wide">
              Insight IA
            </span>
          </div>
          <p className="text-[13px] text-[#F0F2F5] leading-relaxed">
            En appliquant ces 3 améliorations, votre score passe de{" "}
            <strong className="font-semibold">87 à 96</strong> — débloquant 4 programmes premium pour{" "}
            <strong className="font-semibold text-emerald-400">+1,2 M€</strong>.
          </p>
        </div>
      </div>
    </div>
  );
}
