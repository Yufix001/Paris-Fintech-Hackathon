import { useNavigate } from "react-router-dom";
import { Navbar } from "@/components/landing/Navbar";
import { Stepper } from "@/components/flow/Stepper";
import { FundingDonut } from "@/components/flow/FundingDonut";
import { ProgramsTable } from "@/components/flow/ProgramsTable";
import { MiniSecurity } from "@/components/flow/MiniSecurity";
import { exportFundingReport } from "@/lib/exportFundingReport";
import { useAgent } from "@/state/AgentContext";

const DownloadIcon = () => (
  <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
    <polyline points="7 10 12 15 17 10" />
    <line x1="12" y1="15" x2="12" y2="3" />
  </svg>
);

const Financements = () => {
  const navigate = useNavigate();
  const { displayedPrograms } = useAgent();

  return (
    <div className="min-h-screen bg-background text-foreground">
      <Navbar />
      <main className="mx-auto w-full max-w-[1100px] px-6 pb-24 pt-12 sm:pt-16">
        <div className="mb-8 text-center">
          <h1
            className="font-sans font-bold text-foreground"
            style={{
              fontSize: "clamp(26px, 4vw, 34px)",
              letterSpacing: "-1.2px",
              lineHeight: 1.1,
            }}
          >
            Trouvez vos financements en 3 minutes
          </h1>
        </div>

        <Stepper current={4} />

        <section
          aria-labelledby="step4-title"
          role="region"
          className="flex flex-col gap-4"
        >
          <h2 id="step4-title" className="sr-only">
            Étape 4 : Financements éligibles
          </h2>

          <FundingDonut />
          <ProgramsTable />

          <div className="mt-4 flex items-center justify-between gap-4">
            <button
              type="button"
              onClick={() => navigate("/diagnostic")}
              className="inline-flex items-center gap-2 rounded-lg px-5 py-3 text-[14px] font-semibold text-foreground transition-colors"
              style={{
                background: "transparent",
                border: "1px solid hsl(var(--border))",
              }}
              onMouseEnter={(e) =>
                (e.currentTarget.style.background =
                  "hsl(var(--surface-elevated))")
              }
              onMouseLeave={(e) =>
                (e.currentTarget.style.background = "transparent")
              }
            >
              ← Retour au diagnostic
            </button>
            <button
              type="button"
              onClick={() => exportFundingReport(displayedPrograms)}
              className="btn-violet inline-flex items-center gap-2 rounded-lg px-6 py-3 text-[14px] font-semibold"
            >
              Exporter le rapport (PDF)
              <DownloadIcon />
            </button>
          </div>
        </section>

        <MiniSecurity />
      </main>
    </div>
  );
};

export default Financements;
