import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";

type Program = {
  name: string;
  org: string;
  amount: string;
  match: number;
  delay: string;
};

export const exportFundingReport = (programs: Program[]) => {
  const doc = new jsPDF({ unit: "pt", format: "a4" });
  const pageWidth = doc.internal.pageSize.getWidth();
  const margin = 40;

  // Header band
  doc.setFillColor(168, 85, 247);
  doc.rect(0, 0, pageWidth, 80, "F");
  doc.setTextColor(255, 255, 255);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(20);
  doc.text("SubventionAI — Rapport de financements", margin, 38);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(11);
  doc.text("PaymentFlow SAS · Pitch deck analysé", margin, 60);

  // Summary block
  let y = 110;
  doc.setTextColor(20, 20, 22);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(13);
  doc.text("Synthèse", margin, y);
  y += 18;
  doc.setFont("helvetica", "normal");
  doc.setFontSize(11);
  doc.setTextColor(80, 80, 88);
  const summary = [
    "Total éligible : 5,8 M€  ·  dont 2,1 M€ non-dilutif",
    `Programmes recommandés : ${programs.length}`,
    "Répartition : Subventions EU 24% · Aides FR 12% · VC 55% · Prêts 9%",
  ];
  summary.forEach((line) => {
    doc.text(line, margin, y);
    y += 16;
  });

  y += 10;

  // Programs table
  autoTable(doc, {
    startY: y,
    head: [["Programme", "Organisme", "Montant", "Match", "Délai"]],
    body: programs.map((p) => [
      p.name,
      p.org,
      p.amount,
      `${p.match}%`,
      p.delay,
    ]),
    margin: { left: margin, right: margin },
    styles: {
      fontSize: 9.5,
      cellPadding: 6,
      textColor: [40, 40, 44],
    },
    headStyles: {
      fillColor: [26, 28, 32],
      textColor: [240, 242, 245],
      fontStyle: "bold",
      fontSize: 9,
    },
    alternateRowStyles: { fillColor: [248, 248, 250] },
    columnStyles: {
      2: { halign: "right", fontStyle: "bold" },
      3: { halign: "center", fontStyle: "bold", textColor: [22, 163, 74] },
      4: { halign: "center" },
    },
  });

  // Footer
  const pageCount = doc.getNumberOfPages();
  for (let i = 1; i <= pageCount; i++) {
    doc.setPage(i);
    const h = doc.internal.pageSize.getHeight();
    doc.setFontSize(9);
    doc.setTextColor(140, 140, 148);
    doc.text(
      `SubventionAI · Confidentiel · Page ${i}/${pageCount}`,
      margin,
      h - 20,
    );
    doc.text(
      new Date().toLocaleDateString("fr-FR"),
      pageWidth - margin,
      h - 20,
      { align: "right" },
    );
  }

  doc.save("SubventionAI_Rapport_PaymentFlow.pdf");
};
