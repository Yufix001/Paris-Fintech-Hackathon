// Production API client for the FundsAgent backend.
// Base URL points to our Cloud Run deployment.
export const API_BASE =
  "https://fundsagent-636947342773.europe-west1.run.app";

// ---------- Types ----------

export type ParsedPayload = {
  // Free-form parsed data extracted from the pitch deck.
  // Kept loose so the frontend can render whatever the backend returns.
  [key: string]: unknown;
};

export type MatchedProgram = {
  name: string;
  org?: string;
  amount?: string;
  amountSub?: string;
  match?: number; // 0-100
  delay?: string;
  category?: "subvention" | "aide_fr" | "pret";
  [key: string]: unknown;
};

export type MatchedVc = {
  name: string;
  city?: string;
  background?: string;
  country?: string;
  strategies?: string;
};

export type CombosPayload = { [key: string]: unknown };
export type PlanPayload = { [key: string]: unknown };
export type DossierPayload = { [key: string]: unknown };

export type AgentEvent =
  | { type: "parsed"; payload: ParsedPayload }
  | { type: "matched"; payload: { programs: MatchedProgram[] } }
  | { type: "combos"; payload: CombosPayload }
  | { type: "matched_vcs"; payload: { vcs: MatchedVc[] } }
  | { type: "plan"; payload: PlanPayload }
  | { type: "dossier"; payload: DossierPayload }
  // Fallback for forward-compatible event types we don't know about yet.
  | { type: string; payload: unknown };

// ---------- Upload (PDF / PPTX → text) ----------

export async function uploadDeck(file: File): Promise<{ text: string }> {
  const form = new FormData();
  form.append("file", file);

  const res = await fetch(`${API_BASE}/api/upload`, {
    method: "POST",
    body: form,
  });
  if (!res.ok) {
    throw new Error(`Upload failed: ${res.status} ${res.statusText}`);
  }
  return res.json();
}

// ---------- SSE stream ----------

export type StreamAgentOptions = {
  pitchdeck_text: string;
  want_draft?: boolean;
  signal?: AbortSignal;
  onEvent: (event: AgentEvent) => void;
};

/**
 * Calls POST /api/agent/run and parses the Server-Sent Events stream.
 * Each `data: { ... }` line is decoded into an AgentEvent and forwarded
 * to `onEvent`. Resolves once the stream closes cleanly.
 */
export async function streamAgent({
  pitchdeck_text,
  want_draft = true,
  signal,
  onEvent,
}: StreamAgentOptions): Promise<void> {
  const res = await fetch(`${API_BASE}/api/agent/run`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Accept: "text/event-stream",
    },
    body: JSON.stringify({ pitchdeck_text, want_draft }),
    signal,
  });

  if (!res.ok || !res.body) {
    throw new Error(`Agent stream failed: ${res.status} ${res.statusText}`);
  }

  const reader = res.body.getReader();
  const decoder = new TextDecoder("utf-8");
  let buffer = "";

  // Process line-by-line; SSE messages are separated by blank lines but
  // each data line is a complete JSON payload in this API.
  while (true) {
    const { value, done } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });

    // Split on newlines, keep the trailing partial line in buffer.
    const lines = buffer.split(/\r?\n/);
    buffer = lines.pop() ?? "";

    for (const line of lines) {
      const trimmed = line.trim();
      if (!trimmed || !trimmed.startsWith("data:")) continue;
      const jsonStr = trimmed.slice(5).trim();
      if (!jsonStr || jsonStr === "[DONE]") continue;

      try {
        const evt = JSON.parse(jsonStr) as AgentEvent;
        if (evt && typeof evt.type === "string") {
          onEvent(evt);
        }
      } catch (err) {
        // Skip malformed lines but don't kill the stream.
        // eslint-disable-next-line no-console
        console.warn("[streamAgent] failed to parse SSE line", err, jsonStr);
      }
    }
  }

  // Flush any trailing buffered line.
  const tail = buffer.trim();
  if (tail.startsWith("data:")) {
    const jsonStr = tail.slice(5).trim();
    if (jsonStr && jsonStr !== "[DONE]") {
      try {
        const evt = JSON.parse(jsonStr) as AgentEvent;
        if (evt && typeof evt.type === "string") onEvent(evt);
      } catch {
        /* ignore */
      }
    }
  }
}

// ---------- Mappers ----------

/**
 * Converts a raw VC from the `matched_vcs` SSE event into the Program
 * shape consumed by ProgramsTable. VCs are dilutive (equity) financing,
 * so they always get the `vc` category, the "Dilutif" label, and a
 * 100% match gauge.
 */
export type ProgramRow = {
  name: string;
  org: string;
  amount: string;
  amountSub?: string;
  match: number;
  delay: string;
  category: "subvention" | "aide_fr" | "vc" | "pret";
  kind?: "Dilutif" | "Non-dilutif";
};

export function vcToProgram(vc: MatchedVc): ProgramRow {
  const orgParts = [vc.city, vc.country].filter(Boolean).join(" · ");
  const strategies = vc.strategies?.trim();
  const background = vc.background?.trim();
  const orgDescription =
    [orgParts, strategies || background].filter(Boolean).join(" — ") ||
    "Venture Capital";

  return {
    name: vc.name,
    org: orgDescription,
    amount: "Montant variable (Equity)",
    match: 100,
    delay: "Variable",
    category: "vc",
    kind: "Dilutif",
  };
}
